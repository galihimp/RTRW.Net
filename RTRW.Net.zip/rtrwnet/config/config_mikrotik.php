<?php
// Konfigurasi Mikrotik
$mikrotik_ip = '192.168.88.1'; // IP Mikrotik
$mikrotik_user = 'admin'; // Username Mikrotik
$mikrotik_pass = ''; // Password Mikrotik
$mikrotik_port = 200; // Port API Mikrotik

// Include class RouterOS API
require_once __DIR__ . '/routeros_api.php';

// Inisialisasi koneksi
$api = new RouterosAPI();
$mikrotik_connected = false;

// Coba koneksi ke Mikrotik
try {
    $mikrotik_connected = $api->connect($mikrotik_ip, $mikrotik_user, $mikrotik_pass, $mikrotik_port);
    
    if (!$mikrotik_connected) {
        // Gunakan properti error yang sudah ada di class
        $error_msg = "Gagal terhubung ke Mikrotik. Error: " . $api->error_no . " - " . $api->error_str;
        error_log($error_msg);
    }
} catch (Exception $e) {
    $error_msg = "Exception saat koneksi ke Mikrotik: " . $e->getMessage();
    error_log($error_msg);
    $mikrotik_connected = false;
}

// Fungsi untuk mendapatkan pesan error koneksi
function get_mikrotik_error() {
    global $api;
    return $api->error_no . " - " . $api->error_str;
}
?>