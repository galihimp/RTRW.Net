<style>
    /* Sidebar dasar tema Kinet */
    aside.sidebar {
        background-color: #2A3F54 !important;
        color: #ffffff !important;
        width: 240px;
        min-height: 100vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        user-select: none;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    /* User Profile Section */
    .user-profile-section {
        padding: 20px;
        text-align: center;
        border-bottom: 1px solid #425668;
        margin-bottom: 10px;
        color: white;
    }
    .user-avatar {
        width: 70px !important;
        height: 70px !important;
        border-radius: 50% !important;
        margin: 0 auto 10px auto !important;
        overflow: hidden !important;
        border: 2px solid #1ABB9C !important;
    }
    .user-avatar img {
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
        transition: transform 0.3s ease;
    }
    .user-avatar img:hover {
        transform: scale(1.1);
    }
    .user-info h6 {
        margin: 0;
        font-size: 14px;
        font-weight: 600;
    }
    .user-info small {
        color: #B0BEC5;
        font-size: 12px;
    }

    /* Menu Styling */
    ul.sidebar-menu {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    ul.sidebar-menu > li {
        border-top: 1px solid #425668;
    }
    ul.sidebar-menu > li:first-child {
        border-top: none;
    }
    ul.sidebar-menu li a {
        display: flex;
        align-items: center;
        padding: 12px 20px;
        color: #ffffff;
        text-decoration: none;
        font-size: 14px;
        transition: background-color 0.3s ease;
        user-select: none;
    }
    ul.sidebar-menu li a.active,
    ul.sidebar-menu li a:hover {
        background-color: #1ABB9C;
        color: #ffffff;
    }
    ul.sidebar-menu li a i.menu-icon {
        margin-right: 10px;
        min-width: 18px;
        text-align: center;
    }
    ul.sidebar-menu li.has-submenu > a.menu-toggle {
        justify-content: space-between;
        cursor: pointer;
    }
    ul.sidebar-menu li.has-submenu > a.menu-toggle i.menu-arrow {
        transition: transform 0.3s ease;
    }
    ul.sidebar-menu li.has-submenu.open > a.menu-toggle i.menu-arrow {
        transform: rotate(180deg);
    }
    ul.sidebar-menu ul.submenu {
        list-style: none;
        padding-left: 30px;
        display: none;
        background-color: #244563;
        user-select: none;
    }
    ul.sidebar-menu ul.submenu li a {
        padding: 10px 20px;
        font-size: 13px;
        color: #B0BEC5;
    }
    ul.sidebar-menu ul.submenu li a:hover {
        background-color: #1ABB9C;
        color: #fff;
    }

    /* Sidebar Footer */
    .sidebar-footer {
        border-top: 1px solid #425668;
        padding: 10px 0;
        display: flex;
        justify-content: center;
        gap: 25px;
    }
    .sidebar-footer a {
        color: #B0BEC5;
        font-size: 18px;
        transition: color 0.3s ease;
        user-select: none;
    }
    .sidebar-footer a:hover {
        color: #1ABB9C;
    }
</style>

<!-- Sidebar HTML (sama seperti sebelumnya, hanya styling yang berubah) -->
<aside class="sidebar" id="sidebar">
    <!-- User Profile Section -->
    <div class="user-profile-section">
        <div class="user-avatar">
            <?php
            // Logo base64 code tetap sama
            $logo_base64 = '';
            $has_logo = false;
            $logo_paths = [
                '../img/logo.png', './img/logo.png', 'img/logo.png',
                '../login.png', './login.png', 'login.png'
            ];
            foreach ($logo_paths as $path) {
                if (file_exists($path) && is_readable($path)) {
                    clearstatcache(true, $path);
                    $image_data = file_get_contents($path);
                    if ($image_data !== false) {
                        $logo_base64 = 'data:image/png;base64,' . base64_encode($image_data);
                        $has_logo = true;
                        break;
                    }
                }
            }
            ?>
            <?php if ($has_logo): ?>
                <img src="<?= $logo_base64 ?>" alt="Logo">
            <?php else: ?>
                <div style="width: 100%; height: 100%; background: #1ABB9C; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-user" style="color: white; font-size: 24px;"></i>
                </div>
            <?php endif; ?>
        </div>
        <div class="user-info">
            <h6><?= htmlspecialchars($current_user['nama_lengkap'] ?? 'Guest') ?></h6>
            <small><?= htmlspecialchars($current_user['level'] ?? '') ?></small>
        </div>
    </div>

    <!-- Menu -->
    <ul class="sidebar-menu">
        <li>
            <a href="../admin/dashboard.php" class="active">
                <i class="fas fa-home menu-icon"></i>
                <span class="menu-text">Dashboard</span>
            </a>
        </li>

        <li class="has-submenu">
            <a href="#" class="menu-toggle">
                <i class="fas fa-users menu-icon"></i>
                <span class="menu-text">Pelanggan</span>
                <i class="fas fa-chevron-down menu-arrow"></i>
            </a>
            <ul class="submenu">
                <li><a href="../pelanggan/data_pelanggan.php">Data Pelanggan</a></li>
                <li><a href="../pelanggan/tambah_pelanggan.php">Tambah Pelanggan</a></li>
                <li><a href="../pelanggan/active_pelanggan.php">Pelanggan Active</a></li>
            </ul>
        </li>

        <li class="has-submenu">
            <a href="#" class="menu-toggle">
                <i class="fas fa-wifi menu-icon"></i>
                <span class="menu-text">Hotspot</span>
                <i class="fas fa-chevron-down menu-arrow"></i>
            </a>
            <ul class="submenu">
                <li><a href="../hotspot/list_profile.php">Profile Hotspot</a></li>
                <li><a href="../hotspot/add_profile.php">Tambah Profile</a></li>
                <li><a href="../hotspot/voucher_list.php">List Voucher</a></li>
                <li><a href="../hotspot/generate_voucher.php">Generate Voucher</a></li>
                <li><a href="../hotspot/active_voucher.php">Active Voucher</a></li>
            </ul>
        </li>

        <li class="has-submenu">
            <a href="#" class="menu-toggle">
                <i class="fas fa-globe menu-icon"></i>
                <span class="menu-text">Paket Internet</span>
                <i class="fas fa-chevron-down menu-arrow"></i>
            </a>
            <ul class="submenu">
                <li><a href="../paket/list_paket_pppoe.php">Profile PPPoE</a></li>
                <li><a href="../paket/tambah_paket_pppoe.php">Tambah Profile</a></li>
            </ul>
        </li>

        <li>
            <a href="../tagihan/data_tagihan.php">
                <i class="fas fa-file-invoice-dollar menu-icon"></i>
                <span class="menu-text">Tagihan</span>
            </a>
        </li>

        <li>
            <a href="../finance/mutasi_keuangan.php">
                <i class="fas fa-file-invoice-dollar menu-icon"></i>
                <span class="menu-text">Riwayat Transaksi</span>
            </a>
        </li>

        <li class="has-submenu">
            <a href="#" class="menu-toggle">
                <i class="fas fa-globe menu-icon"></i>
                <span class="menu-text">FTTH</span>
                <i class="fas fa-chevron-down menu-arrow"></i>
            </a>
            <ul class="submenu">
                <li><a href="../ftth/data_pop.php">Point of Presence (POP)</a></li>
                <li><a href="../ftth/data_olt.php">Optical Line Terminal (OLT)</a></li>
                <li><a href="../ftth/data_odc.php">Optical Distribution Cabinet (ODC)</a></li>
                <li><a href="../ftth/data_odp.php">Optical Distribution Point (ODP)</a></li>
            </ul>
        </li>

        <li class="has-submenu">
            <a href="#" class="menu-toggle">
                <i class="fas fa-cogs menu-icon"></i>
                <span class="menu-text">Pengaturan</span>
                <i class="fas fa-chevron-down menu-arrow"></i>
            </a>
            <ul class="submenu">
                <li><a href="../settings/perusahaan.php">Data Perusahaan</a></li>
                <li><a href="../settings/mikrotik.php">Mikrotik API</a></li>
            <a href="../logout.php">
        <i class="fas fa-sign-out-alt menu-icon"></i>
        <span class="menu-text">Logout</span>
    </a>
</li>
            </ul>
        </li>
    </ul>

    <!-- Sidebar Footer -->
    <div class="sidebar-footer" data-bs-toggle="tooltip" data-bs-placement="top">
        <a href="../settings/perusahaan.php" title="Settings">
            <i class="fas fa-cog"></i>
        </a>
        <a href="../settings/mikrotik.php" title="Mikrotik Settings">
            <i class="fas fa-expand-arrows-alt"></i>
        </a>
        <a href="../pelanggan/data_pelanggan.php" title="Customers">
            <i class="fas fa-lock"></i>
        </a>
        <a href="../logout.php" title="Logout">
            <i class="fas fa-sign-out-alt"></i>
        </a>
    </div>
</aside>

<script>
    // Toggle submenu with Kinet style arrow rotation
    document.querySelectorAll('.menu-toggle').forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const parentLi = this.parentElement;
            parentLi.classList.toggle('open');

            const submenu = this.nextElementSibling;
            if (submenu) {
                if (submenu.style.display === 'block') {
                    submenu.style.display = 'none';
                } else {
                    submenu.style.display = 'block';
                }
            }
        });
    });

    // Initialize Bootstrap tooltips if Bootstrap JS included
    if (typeof bootstrap !== 'undefined') {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.forEach(function (tooltipTriggerEl) {
            new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
</script>
